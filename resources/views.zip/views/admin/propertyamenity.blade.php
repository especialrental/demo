<form method="POST">
              
               
                 
                <section class="content">
                  <div class="row">
                    <div class="col-md-12" style="padding:0px">
                      <div class="box box-info">
                        <div class="box-header">
                          <h3 class="box-title">BEDROOM</h3>
                          
                          <div class="pull-right box-tools">
                            <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                              <i class="fa fa-minus"></i></button>
                          </div>
                         
                        </div>
                        
                        <div class="box-body pad">
                          <div class="row">
                                   
                                                                        <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value="King Bed"> 
<span style="text-transform: capitalize;">King Bed</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value=" Queen Bed"> 
<span style="text-transform: capitalize;"> Queen Bed</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value=" Double Bed"> 
<span style="text-transform: capitalize;"> Double Bed</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value=" Twin Bed"> 
<span style="text-transform: capitalize;"> Twin Bed</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value=" Single Bed"> 
<span style="text-transform: capitalize;"> Single Bed</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value=" Child Bed"> 
<span style="text-transform: capitalize;"> Child Bed</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value=" Baby Crib"> 
<span style="text-transform: capitalize;"> Baby Crib</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value=" Sleep Sofa /Futon"> 
<span style="text-transform: capitalize;"> Sleep Sofa /Futon</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="18">
<input type="checkbox" name="nami18[]" value="Television"> 
<span style="text-transform: capitalize;">Television</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                
                                                       
                        </div>
                      </div>
                    </div>
                    
                  </div>
                 
                </section>




 
                <section class="content">
                  <div class="row">
                    <div class="col-md-12" style="padding:0px">
                      <div class="box box-info">
                        <div class="box-header">
                          <h3 class="box-title">GENERAL</h3>
                          
                          <div class="pull-right box-tools">
                            <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                              <i class="fa fa-minus"></i></button>
                          </div>
                         
                        </div>
                        
                        <div class="box-body pad">
                          <div class="row">
                                   
                                                                        <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Meet and Greet Check-In"> 
<span style="text-transform: capitalize;">Meet and Greet Check-In</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Sauna"> 
<span style="text-transform: capitalize;">Sauna</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Pool Table"> 
<span style="text-transform: capitalize;">Pool Table</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Pet Friendly"> 
<span style="text-transform: capitalize;">Pet Friendly</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="On-Street Parking"> 
<span style="text-transform: capitalize;">On-Street Parking</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Once weekly maid service"> 
<span style="text-transform: capitalize;">Once weekly maid service</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Nightlife"> 
<span style="text-transform: capitalize;">Nightlife</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Museums"> 
<span style="text-transform: capitalize;">Museums</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Mountain Views"> 
<span style="text-transform: capitalize;">Mountain Views</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Long Term"> 
<span style="text-transform: capitalize;">Long Term</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Linens"> 
<span style="text-transform: capitalize;">Linens</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Lift"> 
<span style="text-transform: capitalize;">Lift</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Lakeside Relaxation"> 
<span style="text-transform: capitalize;">Lakeside Relaxation</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Iron and Ironing board"> 
<span style="text-transform: capitalize;">Iron and Ironing board</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Heating"> 
<span style="text-transform: capitalize;">Heating</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Garden"> 
<span style="text-transform: capitalize;">Garden</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Alarm Clock"> 
<span style="text-transform: capitalize;">Alarm Clock</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Garage"> 
<span style="text-transform: capitalize;">Garage</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Gym"> 
<span style="text-transform: capitalize;">Gym</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Fitness Room"> 
<span style="text-transform: capitalize;">Fitness Room</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Doorman"> 
<span style="text-transform: capitalize;">Doorman</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Fans"> 
<span style="text-transform: capitalize;">Fans</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Family Friendly"> 
<span style="text-transform: capitalize;">Family Friendly</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Deck / Patio"> 
<span style="text-transform: capitalize;">Deck / Patio</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Concierge"> 
<span style="text-transform: capitalize;">Concierge</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="City Getaway"> 
<span style="text-transform: capitalize;">City Getaway</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Cinema"> 
<span style="text-transform: capitalize;">Cinema</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Child Friendly"> 
<span style="text-transform: capitalize;">Child Friendly</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Central Air condition"> 
<span style="text-transform: capitalize;">Central Air condition</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Balcony"> 
<span style="text-transform: capitalize;">Balcony</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Beach"> 
<span style="text-transform: capitalize;">Beach</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Billards"> 
<span style="text-transform: capitalize;">Billards</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Babycot"> 
<span style="text-transform: capitalize;">Babycot</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Air conditioning"> 
<span style="text-transform: capitalize;">Air conditioning</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Safe"> 
<span style="text-transform: capitalize;">Safe</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Senior Friendly"> 
<span style="text-transform: capitalize;">Senior Friendly</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Shopping"> 
<span style="text-transform: capitalize;">Shopping</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Singles Friendly"> 
<span style="text-transform: capitalize;">Singles Friendly</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Sightseeing"> 
<span style="text-transform: capitalize;">Sightseeing</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Swimming Pool"> 
<span style="text-transform: capitalize;">Swimming Pool</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Terrace"> 
<span style="text-transform: capitalize;">Terrace</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Theater"> 
<span style="text-transform: capitalize;">Theater</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Theme Park"> 
<span style="text-transform: capitalize;">Theme Park</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Towels Provided"> 
<span style="text-transform: capitalize;">Towels Provided</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Video Games/Console"> 
<span style="text-transform: capitalize;">Video Games/Console</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Water Views"> 
<span style="text-transform: capitalize;">Water Views</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Wheelchair Accessible"> 
<span style="text-transform: capitalize;">Wheelchair Accessible</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Zoo "> 
<span style="text-transform: capitalize;">Zoo </span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="13">
<input type="checkbox" name="nami13[]" value="Hair Dryer"> 
<span style="text-transform: capitalize;">Hair Dryer</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                
                                                       
                        </div>
                      </div>
                    </div>
                    
                  </div>
                 
                </section>




 
                <section class="content">
                  <div class="row">
                    <div class="col-md-12" style="padding:0px">
                      <div class="box box-info">
                        <div class="box-header">
                          <h3 class="box-title">KITCHEN    </h3>
                          
                          <div class="pull-right box-tools">
                            <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                              <i class="fa fa-minus"></i></button>
                          </div>
                         
                        </div>
                        
                        <div class="box-body pad">
                          <div class="row">
                                   
                                                                        <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value="Barbecue"> 
<span style="text-transform: capitalize;">Barbecue</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Breakfast"> 
<span style="text-transform: capitalize;"> Breakfast</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Coffee Maker"> 
<span style="text-transform: capitalize;"> Coffee Maker</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Cooking Utensils"> 
<span style="text-transform: capitalize;"> Cooking Utensils</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Cutlery"> 
<span style="text-transform: capitalize;"> Cutlery</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Dishwasher"> 
<span style="text-transform: capitalize;"> Dishwasher</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Dryer"> 
<span style="text-transform: capitalize;"> Dryer</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Freezer"> 
<span style="text-transform: capitalize;"> Freezer</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Fridge"> 
<span style="text-transform: capitalize;"> Fridge</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Glasses"> 
<span style="text-transform: capitalize;"> Glasses</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Grill"> 
<span style="text-transform: capitalize;"> Grill</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Kettle"> 
<span style="text-transform: capitalize;"> Kettle</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Meals Provided"> 
<span style="text-transform: capitalize;"> Meals Provided</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Microwave"> 
<span style="text-transform: capitalize;"> Microwave</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Oven"> 
<span style="text-transform: capitalize;"> Oven</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" OvenMix"> 
<span style="text-transform: capitalize;"> OvenMix</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Plates"> 
<span style="text-transform: capitalize;"> Plates</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Toaster"> 
<span style="text-transform: capitalize;"> Toaster</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value=" Washing Machine"> 
<span style="text-transform: capitalize;"> Washing Machine</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="17">
<input type="checkbox" name="nami17[]" value="Stove"> 
<span style="text-transform: capitalize;">Stove</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                
                                                       
                        </div>
                      </div>
                    </div>
                    
                  </div>
                 
                </section>




 
                <section class="content">
                  <div class="row">
                    <div class="col-md-12" style="padding:0px">
                      <div class="box box-info">
                        <div class="box-header">
                          <h3 class="box-title">LIVING ROOM/DINNING AREA    </h3>
                          
                          <div class="pull-right box-tools">
                            <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                              <i class="fa fa-minus"></i></button>
                          </div>
                         
                        </div>
                        
                        <div class="box-body pad">
                          <div class="row">
                                   
                                                                        <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value="Dinning Table"> 
<span style="text-transform: capitalize;">Dinning Table</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value=" Chairs"> 
<span style="text-transform: capitalize;"> Chairs</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value=" Fireplace "> 
<span style="text-transform: capitalize;"> Fireplace </span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value="DVD player"> 
<span style="text-transform: capitalize;">DVD player</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value=" CD Player"> 
<span style="text-transform: capitalize;"> CD Player</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value="Flat screen TV"> 
<span style="text-transform: capitalize;">Flat screen TV</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value=" Sofa bed"> 
<span style="text-transform: capitalize;"> Sofa bed</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value=" Standard TV channels"> 
<span style="text-transform: capitalize;"> Standard TV channels</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value="Wireless internet"> 
<span style="text-transform: capitalize;">Wireless internet</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value="Wooden flooring"> 
<span style="text-transform: capitalize;">Wooden flooring</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value="Cable Internet"> 
<span style="text-transform: capitalize;">Cable Internet</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="14">
<input type="checkbox" name="nami14[]" value=" Telephone"> 
<span style="text-transform: capitalize;"> Telephone</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                
                                                       
                        </div>
                      </div>
                    </div>
                    
                  </div>
                 
                </section>




 
                <section class="content">
                  <div class="row">
                    <div class="col-md-12" style="padding:0px">
                      <div class="box box-info">
                        <div class="box-header">
                          <h3 class="box-title">BATHROOM</h3>
                          
                          <div class="pull-right box-tools">
                            <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                              <i class="fa fa-minus"></i></button>
                          </div>
                         
                        </div>
                        
                        <div class="box-body pad">
                          <div class="row">
                                   
                                                                        <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value="Full"> 
<span style="text-transform: capitalize;">Full</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Separate Toilet"> 
<span style="text-transform: capitalize;"> Separate Toilet</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Combination Tub/Shower"> 
<span style="text-transform: capitalize;"> Combination Tub/Shower</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Tub"> 
<span style="text-transform: capitalize;"> Tub</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value="  Shower"> 
<span style="text-transform: capitalize;">  Shower</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Jetted Tub"> 
<span style="text-transform: capitalize;"> Jetted Tub</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Outdoor shower"> 
<span style="text-transform: capitalize;"> Outdoor shower</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Titled"> 
<span style="text-transform: capitalize;"> Titled</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Half"> 
<span style="text-transform: capitalize;"> Half</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Soap &amp; Shampoo"> 
<span style="text-transform: capitalize;"> Soap &amp; Shampoo</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Sauna"> 
<span style="text-transform: capitalize;"> Sauna</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Jacuzzi"> 
<span style="text-transform: capitalize;"> Jacuzzi</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                                                      <div class="col-sm-3">
                                        <div class="checkbox">
                                            <label>


<input type="hidden" name="ameid[]" value="19">
<input type="checkbox" name="nami19[]" value=" Hot Tub"> 
<span style="text-transform: capitalize;"> Hot Tub</span> 
     
     
                                                
                                            </label>
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                
                                                       
                        </div>
                      </div>
                    </div>
                    
                  </div>
                 
                </section>




                
                
                <a href="gallery.php"> <button type="button" class="btn btn-info pull-right" style="margin: 0px 0px 0px 12px;">Next </button></a>
               <button type="submit" name="add_amenity" class="btn btn-success btn-outline-rounded green"> Submit / Update <span style="margin-left:10px;" class="glyphicon glyphicon-send"></span></button>            
            </form>