<p>Hi, This is <b>{{ $data['name'] }}</b></p>
<p>I have some query like <b>{{ $data['message'] }}.</b></p>

<p>It would be appriciative, if you gone through this feedback.</p>

